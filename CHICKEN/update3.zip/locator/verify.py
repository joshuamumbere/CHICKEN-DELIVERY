# Import necessary libraries
from kivymd.app import MDApp
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.lang import Builder
from kivymd.icon_definitions import md_icons
from kivymd.uix.button import MDIconButton
from kivy.core.window import Window
import mysql.connector
import bcrypt
from kivy.uix.popup import Popup
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.uix.button import Button
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivymd.uix.bottomnavigation import MDBottomNavigation, MDBottomNavigationItem
from kivymd.uix.button import MDIconButton
from kivymd.uix.bottomnavigation import MDBottomNavigation
from kivymd.uix.bottomnavigation import MDBottomNavigationItem
from kivymd.uix.menu import MDDropdownMenu


# Set up the database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sign_up"
)

cursor = db.cursor()

# Create users table if not exists
create_table_query = """
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(100)
)
"""
cursor.execute(create_table_query)
db.commit()

# Window size configuration
Window.size = (323, 550)

class ImageButton(Button):
    pass
class ClickableImage(ButtonBehavior, Image):
    pass


# Signup Screen
class SignupScreen(Screen):
    def signup(self):
        name = self.ids.name.text
        email = self.ids.email.text
        password = self.ids.signup_password.text.encode('utf-8')

        # Validate that none of the fields are empty
        if not name or not email or not password:
            self.ids.result_label.text = "Please fill all fields."
            return

        # Hash the password
        hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())

        # Check if the user already exists
        check_user_query = "SELECT * FROM users WHERE email = %s"
        cursor.execute(check_user_query, (email,))
        existing_user = cursor.fetchone()

        if existing_user:
            self.ids.result_label.text = "User already exists!"
        else:
            # Insert the new user with name, email, and hashed password
            insert_user_query = "INSERT INTO users (name, email, password) VALUES (%s, %s, %s)"
            cursor.execute(insert_user_query, (name, email, hashed_password))
            db.commit()
            self.ids.result_label.text = "User signed up successfully!"
            MyApp.sm.current = 'login'

    def toggle_password_visibility(self, password_field_id):
        password_field = self.ids.get(password_field_id)
        password_field.password = not password_field.password

        # Access the MDIconButton directly using the ID
        icon_button = self.ids.get(f'{password_field_id}_visibility')

        if icon_button:
            icon = "eye" if not password_field.password else "eye-off"
            icon_button.icon = icon
        else:
            print(f"MDIconButton not found for {password_field_id}")

# Login Screen
class LoginScreen(Screen):
    def login(self):
        email = self.ids.login_email.text
        password = self.ids.login_password.text.encode('utf-8')

        # Validate that none of the fields are empty
        if not email or not password:
            self.ids.result_label.text = "Please fill in all fields."
            return

        # Check if the user exists
        check_user_query = "SELECT * FROM users WHERE email = %s"
        cursor.execute(check_user_query, (email,))
        existing_user = cursor.fetchone()

        if existing_user:
            # Check the password using bcrypt
            stored_password = existing_user[3].encode('utf-8')  # Assuming password is at index 3
            if bcrypt.checkpw(password, stored_password):
                self.ids.result_label.text = "Login successful!"
                self.clear_inputs()  # Clear input fields on successful login
                MyApp().show_loading_icon()
                MyApp.sm.current = 'splash'
            else:
                self.ids.result_label.text = "Invalid password!"
                self.clear_inputs()  # Clear input fields on invalid password
        else:
            self.ids.result_label.text = "Invalid Login!"
            self.clear_inputs()  # Clear input fields on invalid credentials

    def clear_inputs(self):
        # Clear input fields
        self.ids.login_email.text = ""
        self.ids.login_password.text = ""

    def toggle_password_visibility(self, password_field_id):
        password_field = self.ids[password_field_id]
        icon_button = self.ids[f'{password_field_id}_visibility']

        if password_field.password:
            password_field.password = False
            icon_button.icon = "eye"
        else:
            password_field.password = True
            icon_button.icon = "eye-off"
class HomeScreen(Screen):
    
  pass

class AdminScreen(Screen):
    pass


# Add this class definition before your other screen classes
class SplashScreen(Screen):
    def on_enter(self, *args):
        # Show the splash screen for 2 seconds and then transition to the login screen
        Clock.schedule_once(self.show_home_screen, 3)

    def show_home_screen(self, dt):
        MyApp.sm.current = 'home'




# Kivy App
class MyApp(MDApp):
    sm = None

    def show_loading_icon(self):
        popup_content = Image(source='locate.png', size=(500, 500))
        self.popup = Popup(content=popup_content, auto_dismiss=False, size_hint=(None, None), size=(500, 500), title='')

        # Bounce-out animation
        bounce_out_animation = Animation(size=(0, 0), duration=3, t='out_bounce')
        bounce_out_animation.start(self.popup)

        def close_popup(dt):
            self.popup.dismiss()
            MyApp.sm.current = 'home'

        Clock.schedule_once(close_popup, 3)
        self.popup.open()

    def build(self):
        self.root = Builder.load_file('screens.kv')
        self.theme_cls.theme_style = "Dark"
        MyApp.sm = ScreenManager()  # Assign ScreenManager to class variable sm

        signup_screen = SignupScreen(name='signup')
        login_screen = LoginScreen(name='login')
        home_screen = HomeScreen(name='home')
        admin_screen = AdminScreen(name='admin')
        splash_screen = SplashScreen(name='splash')
        MyApp.sm.add_widget(login_screen)
        MyApp.sm.add_widget(signup_screen)
        MyApp.sm.add_widget(home_screen)
        MyApp.sm.add_widget(admin_screen)
        MyApp.sm.add_widget(splash_screen)

        return MyApp.sm
        

if __name__ == '__main__':
    MyApp().run()